package com.example.block03;


import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // These 2 lines add a background image to the button labeled "BIG".
        // This is not demonstrated in the step-by-step video,
        // but the summary slide at the end of the video mentions that possibility.
    }
}
